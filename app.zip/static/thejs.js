
function confirmSubmit(popText)
{
    var agree=confirm(popText);
    if (agree)
        return true ;
    else
        return false ;
}